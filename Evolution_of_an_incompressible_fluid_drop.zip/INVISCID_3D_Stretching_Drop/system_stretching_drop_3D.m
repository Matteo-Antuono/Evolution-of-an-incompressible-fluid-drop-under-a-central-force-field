%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% System of ODEs for the 3D INVISCID stretching DROP %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% y(1) indicates the variable "gamma", that is the DIMENSIONLESS elongation 
% of the ellipsoid semi-axis in the (x,y)-plane, 
% y(2) is the time derivative of "gamma" (with respect to the DIMENSIONLESS time)

function dy = system_stretching_drop_3D(~,y)

dy = zeros(2,1);

dy(1) = y(2);
dy(2) = ( 6*y(2)^2 + y(1)^2 * (1-y(1)^6) )/(y(1)*(2+y(1)^6));