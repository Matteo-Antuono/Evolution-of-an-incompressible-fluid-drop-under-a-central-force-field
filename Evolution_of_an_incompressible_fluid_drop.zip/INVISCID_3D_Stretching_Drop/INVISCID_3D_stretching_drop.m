%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  EXACT solution of the 3D INVISCID stretching drop  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear
clc

disp('------------------------------------------');
disp('     EXACT 3D STRETCHING DROP             ');
disp('------------------------------------------');
disp('  ')


%%% DIMENSIONS %%%%%%%%%%%%
% [Om_sq] = s^(-2)    // parameter of the volume force
% [gam0] = []         // DIMENSIONLESS elongation of the semi-axis
% [A0] = s^(-1)       // parameter of the velocity field
% [dgam0] =  []       // DIMENSIONLESS time derivative of 'gam0'


%%% External force (central conservative force field) 
Om_sq = input('Insert the DIMENSIONAL external force \Omega^2:    ');
while (Om_sq <=0)
    disp('the external force must be positive');
    Om_sq  = input('Insert the DIMENSIONAL external force \Omega^2:    ');
end

%%% Initial datum for the dimensionless axis "a/R" of the ellipsoid
gam0 = input('Initial dimensionLESS semi-axis "gam0 = a_0/R":    ');
while (gam0<=0)
    disp('the initial value must be positive');
    gam0 = input('Initial dimensionLESS semi-axis "gam0 = a_0/R":    ');
end

%%% Initial datum for the velocity coefficent "A" (DIMENSIONALE)
A0 = input('Initial value of the dimensional velocity coefficent "A_0":    ');
% evaluating dgam0 = dgamma/dtau(0) (ADIMENSINALE)
dgam0 = A0*gam0/sqrt(Om_sq);


disp('  ')
disp(' MAIN DIMENSIONLESS PARAMETERS')
disp(['  gamma(0) = ', num2str(gam0)])
disp(['  dgamma/dtau(0) = ', num2str(dgam0)])
disp('------------------------------------------');





%%% ANALYTICAL RESULTS %%%%%%%%%%%%

%%% COMPUTING PERIOD 
HH0 = (2+gam0^6)/(2*gam0^6);
FF0 = (1+2*gam0^6)/(4*gam0^4);
CC0 = HH0*(dgam0^2) + FF0;

if (CC0<3/4)
  disp('probemi con C0')
  return
end

% Coefficients of the polynomial under square root in the denominator 
% of the integral argument
Coefs     = [-2,4*CC0,0,-1];
Semi_assi = sort(real( roots(Coefs) ));

q3 = Semi_assi(3);
q2 = Semi_assi(2);
q1 = Semi_assi(1); %out of the interval of integration

disp('DIMENSIONLESS ELONGATION IN THE HORIZONTAL PLANE')
disp(['maximum: gam3 = ', num2str(sqrt(q3))]);
disp(['minimum: gam2 = ', num2str(sqrt(q2))]);
disp('   ');
disp('DIMENSIONLESS ELONGATION IN THE VERTICAL DIRECTION')
disp(['maximum: 1/q2 = ', num2str(1/q2)]);
disp(['minimum: 1/q3 = ', num2str(1/q3)]);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% COMPUTING the PERIOD of OSCILLATION
% discretization
dq = (q3-q2)/1000000;  % spatial step
eps_q = 100*dq;        % length of the intervals for the analytical expression with integration by parts
q  = (q2+eps_q):dq:(q3-eps_q); 


% INNER INTERVAL [q2+eps_q, q3-eps_q]
arg = sqrt(2+q.^3)./(q.*sqrt((q3-q).*(q-q2).*(q-q1)));
int_inner = trapz(q,arg)/sqrt(Om_sq);


% LOWER integral [q2,q2+eps_q]
q2e = q2 + eps_q;

h2e  = sqrt(2+q2e^3)/q2e/sqrt((q3-q2e)*(q2e-q1));
dh2e = -((-q2e * (8 * q2e+q2e^4-6 *q1)+6 *q2e * q3+(-4+q2e^3) * q1 * q3)/...
          (2 * q2e^2 * sqrt(2+q2e^3) * (-(q2e-q1) * (q2e-q3))^(3/2)));

q_low = q2:dq:(q2+eps_q);
ddh2 = (3 * q_low.^10-10 *q_low.^8 * q1 * q3 + 32 * q1.^2 * q3^2 - 80* q1 * q3 * q_low.* (q1+q3)+...
        20 * q_low.^2 .* (3 * q1+q3) .* (q1+3 * q3)+8 * q_low.^5 .* (6 * q1^2+19 * q1 * q3 + 6 * q3^2)+...
        q_low.^4 .* (96-68* q1 *q3 *(q1+q3))+4 *q_low.^7 .* (18+q1 * q3 * (q1+q3))-...
        q_low.^6 .* (108 *q3+q1 *(108+q1 * q3^2))+16 * q_low.^3 .*(-9 *q3+q1 *(-9+2 *q1 *q3^2)))./ ...
        (4 *q_low.^3 .*(2+q_low.^3).^(3/2) .*(-(q_low-q1) .*(q_low-q3)).^(5/2));

arg_low_2   = ddh2.*((q_low-q2).^(3/2));
int_lower_2 = 2*sqrt(eps_q)*h2e -4/3 * eps_q^(3/2) * dh2e +...
              4/3 * trapz(q_low,arg_low_2);
int_lower_2 = int_lower_2/sqrt(Om_sq);



% UPPER interval [q3-eps,q3]
q3e   = q3 - eps_q;

h3e  = sqrt(2 + q3e^3)/q3e/sqrt((q3e - q2)*(q3e - q1));
dh3e = (-q3e * (8 *q3e + q3e^4 - 6 * q1) + 6 * q3e * q2 + (-4 + q3e^3) * q1 * q2)/...
       (2 * q3e^2 * sqrt( 2 + q3e^3) * ((q3e - q1) * (q3e - q2))^(3/2));

q_up  = q3e:dq:q3;

ddh3 = (3 * q_up.^10 - 10 * q_up.^8 *q1 *q2 + 32 *q1^2 *q2^2 - 80 *q_up *q1 *q2 *(q1 + q2) +... 
        20 * q_up.^2 * (3 *q1 + q2) * (q1 + 3 *q2) + 8 *q_up.^5 .*(6 *q1^2 + 19 *q1 *q2 + 6 *q2^2) +...
        q_up.^4 *(96 - 68* q1* q2* (q1 + q2)) + 4* q_up.^7 *(18 + q1 *q2 *(q1 + q2)) - ...
        q_up.^6 *(108* q2 + q1* (108 + q1 *q2^2)) +  16 *q_up.^3 .*(-9 *q2 + q1 *(-9 + 2 *q1 *q2^2)))./...
        (4 *q_up.^3 .*(2 + q_up.^3).^(3/2) .*((q_up - q1) .*(q_up - q2)).^(5/2));
arg_up_3 = ddh3.*((q3-q_up).^(3/2));
int_up_3 = 2*sqrt(eps_q)*h3e +4/3 * eps_q^(3/2) * dh3e +...
              4/3 * trapz(q_low,arg_up_3);
int_up_3 = int_up_3/sqrt(Om_sq);

% Final integral
Tper =  int_lower_2 + int_inner + int_up_3;

disp('   ');
disp(['DIMENSIONAL PERIOD, T = ', num2str(Tper)]);
disp(['DIMENSIONLESS PERIOD, Omega * T = ', num2str(Tper*sqrt(Om_sq))]);
disp('------------------------------------------');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%% COMPUTING the PERIOD of OSCILLATION (OLD WAY - less accurate)
% % discretization
% dq = (q3-q2)/1000000;
% eps_q = dq;  % length of the intervals where apply the analytical approximation
% q  = (q2+eps_q):dq:(q3-eps_q);
% 
% % INNER interval [q2+eps_q, q3-eps_q]
% arg = sqrt(2+q.^3)./(q.*sqrt((q3-q).*(q-q2).*(q-q1)));
% int_inner = trapz(q,arg)/sqrt(Om_sq);
% 
% % LOWER interval [q2,q2+eps_q]
% h2  = sqrt(2+q2^3)./(q2*sqrt((q3-q2)*(q2-q1)));
% dh2 = ((q1 - q2) * (6 * q1 * q2 - q2 * ( 8 * q2 + q2^4 - 6 * q3) +... 
%        q1 * (-4 + q2^3) * q3 ))/(2 * q2^2 * (-q1 + q2) * ...
%        sqrt( 2 + q2^3) * ((q1 - q2) * (q2 - q3))^(3/2));
% int_lower = 2 * h2 * sqrt(eps_q) + (2/3) * dh2 * eps_q^(3/2);
% int_lower = int_lower/sqrt(Om_sq);
% 
% % UPPER INTERVAL [q3-eps_q,q3]
% h3  = sqrt(2+q3^3)/(q3 * sqrt((-q1+q3) * (-q2+q3)));
% dh3 = ((q2-q3) * (4 * q1 * q2 - 6 * (q1+q2)* q3 + 8 * q3^2 - q1 * q2 * q3^3 + q3^5))/ ...
%       (2 * ((q1-q3) * (q2-q3))^(3/2) * q3^2 * (-q2+q3) * sqrt(2+q3^3));
% int_upper = 2 * h3 * sqrt(eps_q) - (2/3) * dh3 * eps_q^(3/2);
% int_upper = int_upper/sqrt(Om_sq);
% 
% % Final Integral
% Tper =  int_lower + int_inner + int_upper;
% 
% disp('   ');
% disp(['DIMENSIONAL PERIOD, T = ', num2str(Tper)]);
% disp(['DIMENSIONLESS PERIOD, Omega * T = ', num2str(Tper*sqrt(Om_sq))]);
% disp('------------------------------------------');
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






%%% NUMERICAL SOLUTION %%%%%%%%%%%
%%% 
%%% y(:,1) = gamma(tau), y(:,2) = dgamma/dtau (horizontal semi-axis)
%%% dimensionLESS time: tau = sqrt(Om_sq) * t

tau_end = 5.5 * Tper * sqrt(Om_sq); 
options = odeset('RelTol',10^(-8),'AbsTol',10^(-8),'MaxStep',tau_end/20000);

[tau,y]=ode23tb(@system_stretching_drop_3D,[0 tau_end],[gam0 dgam0],options); 
v1 = y(:,1); % gam
v2 = y(:,2); % dgam/dtau

time = tau/sqrt(Om_sq);  % DIMENSIONAL time 
gam  = v1;
dgam = v2 * sqrt(Om_sq); % DIMENSIONAL dgamma/dt

A = dgam./gam; % DIMENSIONAL velocity coefficient

time_o_T = time/Tper;  %dimensionless time (scaled by period!)<<<


%%%%%%%%%%%%%%%%%%%%%%%%%%5
figure(1)
plot(time_o_T,gam)
title('dimensionless elongation in the horizontal plane')
xlabel('time/T')
ylabel('\gamma')

figure(2)
plot(time_o_T,1./(gam.^2))
title('dimensionless elongation in the vertical plane')
xlabel('time/T')
ylabel('\delta')
%%%%%%%%%%%%%%%%%%%%%%%%%%5


%%% PRESSURE FIELD at the ORIGIN
%%% reference scale for pressure field: 
%%% p^* = Omega_sq * R^2 * rho0
%
ddgam = (6 * v2.^2 + (v1.^2) .* (1 - v1.^6) )./ ...
        ( v1.* (2 + v1.^6));
ddgam = ddgam * Om_sq; % DIMENSIONAL dgamma^2/dt^2
dA    = (gam.*ddgam - dgam.^2)./(gam.^2);

% dimensionless pressure: p* = p /rho_0 / (R^2* Omega^2)  
p_adim = 0.5 *(gam.^2) .* ( Om_sq + A.^2 + dA )/Om_sq;

figure(3)
plot(time_o_T,p_adim)
title('dimensionless pressure at the origin')
xlabel('time/T')
ylabel('p^*')
%%%%%%%%%%%%%%%%%%%%%%%%%%5




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% ENERGY TERMS %%%

% TOTAL MECHANICAL ENERGY
% NOTE: the total mechanical energy is displayes in order to check
% the numerical dissipation induced by the numerical integration of the ODEs. 
% Indeed, in theory the total mechanical energy has to be constant in time.
HH = (2+v1.^6)./(2*v1.^6);
FF = (1+2*v1.^6)./(4*v1.^4);
Etot = HH.*(v2.^2)+FF-CC0;   %NOTE: defined up to an unessential constant value

figure(4)
plot(time_o_T,Etot)
title('dimensionless TOTAL ENERGY')
subtitle('-- check on numerical dissipation --')
xlabel('time/T')
ylabel('E_{tot}^*')


% POTENTIAL and KINETIC energies
Epot = 2/5 * FF;
Ekin = 2/5 * HH.*(v2.^2);

figure(5)
plot(time_o_T,Epot)
title('dimensionless POTENTIAL ENERGY')
xlabel('time/T')
ylabel('E_{pot}^*')

figure(6)
plot(time_o_T,Ekin)
title('dimensionless KINETIC ENERGY')
xlabel('time/T')
ylabel('E_{kin}^*')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%