%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% LINEARIZED solution for the 3D viscous stretching drop %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


close all
clear
clc

% Physical parameters
%
% DIMENSIONAL:
% R = radius of the undisturbed sphere
% nu = kinematic viscosity
% Omega^2 = coefficient of the radia force
% sigma = surface tension parameter
%
% DIMENSIONLESS 
% zeta = Omega^2 R^4 / nu^2
% chi = sigma R / nu^2
% U = 2*zeta + 8*chi
%
% DAMPING RATE SCALE (DIMENSIONAL)
% beta = nu / R^2



%=========================================================================
% We assign beta, U, Omega^2 and R and
% derive the valus of nu and sigma from them
% NB: 'sigma' denotes 'sigma/rho_0'
%----------------------------------------------
% U = (2 * Omega^2 + 8 * sigma/rho_0/R^3 )
% beta = nu/R^2

beta = 0.01;

U = 5000;    %it must be greater than 25 for oscillatory regime! <<<<<
if (U<=25) 
  disp('U must be grater than 25 to ensure oscillatory regime!')
  return
end

Omega_sq = 1/4; % Omega^2
R = 1;          % radius

%derived quantities
nu    = beta * R^2;
sigma = ( beta^2 * U - 2*Omega_sq )*R^3/8;  % 'sigma/rho_0'
zeta  = Omega_sq/beta^2;
chi   = (U - 2*zeta )/8;


if (sigma<0)
    disp('WRONG choise of parameters: sigma is negative')
    disp('choose U such that:  Omega_sq <= 1/2 beta^2 * U')
    return
end

disp('-------------------------------')
disp('CHOSEN parameters')
disp(['beta = ',num2str(beta),',  U = ',num2str(U)])
disp(['   R = ',num2str(R),',  Omega_sq = ',num2str(Omega_sq)])

disp('-------------------------------')
disp('DERIVED parameters')
disp(['  nu = ',num2str(nu),',  sigma/rho_0 = ',num2str(sigma)])
disp(['zeta = ',num2str(zeta),',  chi = ',num2str(chi)])
%=========================================================================



% Complex Frequency (alpha)
Re_alpha = 5 * beta;
Im_alpha = sqrt(U - 25) * beta;


% time range of the solution
% NB: the maximum time is when the magnitude of the solution is "ratio" times
% the initial magnitude
ratio = 0.04;
T_end = -log(ratio)/Re_alpha;
Np    = 1000; % number of points
dt    = T_end/Np;
time  = 0:dt:T_end;


% Amplitude of the solution 
% I choose the imaginary part in order to start from the undisturbed configuration
% hence I introduce the function H(t) = - sin(Im_alpha*time) * exp(-Re_alpha*time)
epsilon = 0.05;          %perturbation parameter (dimensionless) <<<<<<
H = - sin(Im_alpha*time) .* exp(-Re_alpha*time);
a = R*( 1 + epsilon * H ); 

disp(['epsilon = ', num2str(epsilon)])
disp('-------------------------------------')



% velocity coefficient A
% I use the formula A = dot(a)/a = epsilon*dH/dt/(1+epsilon*H)
% OSS: A ~ epsilon * dH/dt
dHdt = ( -Im_alpha * cos(Im_alpha*time) + Re_alpha * sin(Im_alpha*time) ) .* exp(-Re_alpha*time);
A = epsilon * R * dHdt;
A = A./a;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% evolution of GLOBAL quantities per unit of volume/surface
E_kin = 3/5 * R^2 * A.^2;

E_surf = 1 + 8/5 * epsilon^2 * H.^2;  %over sigma

W_surf = 16/5 * epsilon * H .* A;  %over sigma (time derivative of the previous quantity)

W_diss = 6 * A.^2;

W_force = -12/5 * R^2 * epsilon * A .* H;  %over Omega^2


%%%% FIGURE - PART 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1) 
plot(time,a)
title('a sol')
xlabel('t')

figure(2)
plot(time,A)
title('A sol')
xlabel('t')

figure(3)
plot(time,E_kin)
title('Kinetic Energy')
xlabel('t')

figure(4)
plot(time,E_surf)
title('Surface Tension Energy')
xlabel('t')

figure(5)
plot(time,W_surf)
title('Surface Tension Work')
xlabel('t')

figure(6)
plot(time,W_diss)
title('Work of viscous forces')
xlabel('t')

figure(7)
plot(time,W_force)
title('Work of body forces')
xlabel('t')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% FREE SURFACE EVOLUTION
T_per  = 2*pi/Im_alpha; % period of oscillation
t_step = (0:1:4)/5*T_per;
H_step = - sin(Im_alpha*t_step) .* exp(-Re_alpha*t_step);
a_step = R*( 1 + epsilon * H_step );

theta = 0:0.0005:pi;

nn = length(t_step);

rFS_snap = zeros(nn,length(theta));

for i=1:nn

    aa = a_step(i);

    rFS = 1./sqrt( sin(theta).^2/(aa^2) + (aa^4) * cos(theta).^2/R^6 );
    
    rFS_snap(i,:) = rFS(:);


    figure(10) 
    plot(theta,rFS)
    title('r_{FS} evolution')
    xlabel('\theta')
    hold on

    % plot on the plane y=0 // in pola corrdintes this means
    % angle phi=0 (fixed) while the angle theta varies
    figure(11)
    x = rFS .* sin(theta);
    r = rFS .* cos(theta);
    XX=[x,-x];
    RR=[r,sort(r,'ascend')];
    plot(XX,RR)
    hold on
    title('FS evolution')
    xlabel('x')
    ylabel('z')
    axis equal

end

figure(10)
legend('T1','T2','T3','T4','T5')
figure(11)
legend('T1','T2','T3','T4','T5')



%%% PRESSURE FIELD at the origin
term = (R./a).^6;

ddHddt = (Re_alpha^2 -Im_alpha^2)*H -2*Im_alpha*Re_alpha * cos(Im_alpha*time) .* exp(-Re_alpha*time);

dAdt = (R * epsilon * ddHddt )./a - A.^2;

C0 = (a.^2)/3 .* ( A.^2 .* (1+2*term) + ...
                   dAdt .* (1-term)   + ...
                  Omega_sq * (1+1/2*term) );
C0 = C0 + sigma/R;

figure(8)
plot(time,C0)
title('pressure at the origin')
xlabel('t')


