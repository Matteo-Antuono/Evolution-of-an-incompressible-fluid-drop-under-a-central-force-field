%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  EXACT solution of the 2D INVISCID stretching drop  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear
clc

disp('----------------------------------------');
disp('     2D INVISCID STRETCHING DROP        ');
disp('----------------------------------------');
disp('  ')


%%% DIMENSIONS %%%%%%%%%%%%
% [Om_sq] = s^(-2)    // parameter of the volume force
% [gam0] = []         // DIMENSIONLESS elongation of the semi-axis
% [A0] = s^(-1)       // parameter of the velocity field
% [dgam0] =  []       // DIMENSIONLESS time derivative of 'gam0'


%%% External force (central conservative force field) 
Om_sq = input('Insert the DIMENSIONAL external force \Omega^2:    ');
while (Om_sq <=0)
    disp('the external force must be positive');
    Om_sq  = input('Insert the DIMENSIONAL external force \Omega^2:    ');
end

%%% Initial datum for the dimensionless axis "a/R" of the ellipse
gam0 = input('Initial dimensionLESS semi-axis "gam0 = a_0/R":    ');
while (gam0<=0)
    disp('the initial value must be positive');
    gam0 = input('Initial dimensionLESS semi-axis "gam0 = a_0/R":    ');
end

%%% Initial datum for the velocity coefficent "A" (DIMENSIONAL value)
A0 = input('Initial value of the DIMENSIONAL velocity coefficent "A_0":    ');
% evaluating dgam0 = dgamma/dtau(0) (dimensionLESS)
dgam0 = A0*gam0/sqrt(Om_sq);



disp('  ')
disp(' MAIN DIMENSIONLESS PARAMETERS')
disp(['  gamma(0) = ', num2str(gam0)])
disp(['  dgamma/dtau(0) = ', num2str(dgam0)])
disp('------------------------------------------');





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% ANALYTICAL RESULTS %%%%%%%%%%%%

%%% COMPUTING PERIOD 
HH0 = (1+gam0^4)/(2*gam0^4);
FF0 = (1+gam0^4)/(2*gam0^2);
CC0 = HH0*(dgam0^2) + FF0;

if (CC0<3/4)
  disp('probemi con C0')
  return
end

% radici
q2 = CC0 + sqrt(CC0^2 - 1);
q1 = CC0 - sqrt(CC0^2 - 1);

disp('DIMENSIONLESS ELONGATION')
disp(['maximum: gam2 = ', num2str(sqrt(q2))]);
disp(['minimum: gam1 = ', num2str(sqrt(q1))]);
disp('   ');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% COMPUTING the PERIOD of OSCILLATION
% discretization
dq = (q2-q1)/1000000;  % spatial step
eps_q = 100*dq;        % length of the intervals for the analytical expression with integration by parts
q = (q1+eps_q):dq:(q2-eps_q);


% INNER interval [q1+eps_q, q2-eps_q]
arg = sqrt(1+q.^2)./(q.*sqrt((q2-q).*(q-q1)));
int_inner = trapz(q,arg)/sqrt(Om_sq);


% LOWER integral [q1,q1+eps_q]
q1e  = q1 + eps_q;
h1e  = sqrt(1+q1e^2)/(q1e*sqrt((q2-q1e)));
dh1e = (3 * q1e + q1e^3 - 2 * q2)/...
       (2 * q1e^2 * sqrt(1+q1e^2) * (-q1e+q2)^(3/2));
q_low = q1:dq:(q1+eps_q);
ddh1  = (4 * q2^2 * (2 + 3 * q_low.^2) - 4 *q2 * q_low .* (5+7 *q_low.^2)+...
        q_low.^2 .* (15+22 * q_low.^2+3 * q_low.^4))./ ...
        (4 * (q2-q_low).^(5/2) .* q_low.^3 .* (1+q_low.^2).^(3/2));

arg_low_1   = ddh1.*((q_low-q1).^(3/2));
int_lower_1 = 2*sqrt(eps_q)*h1e -4/3 * eps_q^(3/2) * dh1e +...
              4/3 * trapz(q_low,arg_low_1);
int_lower_1 = int_lower_1/sqrt(Om_sq);


% UPPER interval [q2-eps,q2]
q2e   = q2 - eps_q;
h2e   = sqrt(1+q2e^2)/(q2e*sqrt((q2e-q1)));
dh2e  = (2 * q1 - q2e * (3+q2e^2))/...
      (2 * q2e^2 * (-q1+q2e)^(3/2) * sqrt(1+q2e^2));
q_up  = q2e:dq:q2;

ddh2 = (4 * q1^2 * (2 + 3 * q_up.^2) - 4 * q1 * q_up .* (5 + 7 * q_up.^2) +... 
        q_up.^2 .* (15 + 22 * q_up.^2 + 3 * q_up.^4))./ ...
       (4 * q_up.^3 .* (-q1 + q_up).^(5/2) .* (1 + q_up.^2).^(3/2));
arg_up_2 = ddh2.*((q2-q_up).^(3/2));
int_up_2 = 2*sqrt(eps_q)*h2e +4/3 * eps_q^(3/2) * dh2e +...
              4/3 * trapz(q_low,arg_up_2);
int_up_2 = int_up_2/sqrt(Om_sq);


% overall integral
Tper =  int_lower_1 + int_inner + int_up_2;

disp('   ');
disp(['DIMENSIONAL PERIOD, T = ', num2str(Tper)]);
disp(['DIMENSIONLESS PERIOD, Omega * T = ', num2str(Tper*sqrt(Om_sq))]);
disp('------------------------------------------');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%% COMPUTING the PERIOD of OSCILLATION (OLD WAY - less accurate)
% % discretization
% dq = (q2-q1)/1000000;  % spatial step
% eps_q = dq;            % length of the intervals where apply the analytical approximation 
% q = (q1+eps_q):dq:(q2-eps_q);
% 
% % % INNER interval [q1+eps_q, q2-eps_q]
% arg = sqrt(1+q.^2)./(q.*sqrt((q2-q).*(q-q1)));
% int_inner = trapz(q,arg)/sqrt(Om_sq);
% 
% % % LOWER interval [q1,q1+eps_q]
% h1  = sqrt(1+q1^2)/(q1*sqrt((q2-q1)));
% dh1 = (3 * q1 + q1^3 - 2 * q2)/...
%       (2 * q1^2 * sqrt(1+q1^2) * (-q1+q2)^(3/2));
% int_lower = 2 * h1 * sqrt(eps_q) + (2/3) * dh1 * eps_q^(3/2);
% int_lower = int_lower/sqrt(Om_sq);
% 
% % % UPPER interval [q2-eps_q,q2]
% h2  = sqrt(1+q2^2)/(q2*sqrt((q2-q1)));
% dh2 = (2 * q1 - q2 * (3+q2^2))/...
%       (2 * q2^2 * (-q1+q2)^(3/2) * sqrt(1+q2^2));
% int_upper = 2 * h2 * sqrt(eps_q) - (2/3) * dh2 * eps_q^(3/2);
% int_upper = int_upper/sqrt(Om_sq);
% 
% % Final Integral
% Tper =  int_lower + int_inner + int_upper;
% 
% disp('   ');
% disp(['DIMENSIONAL PERIOD, T = ', num2str(Tper)]);
% disp(['DIMENSIONLESS PERIOD, Omega * T = ', num2str(Tper*sqrt(Om_sq))]);
% disp('------------------------------------------');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% NUMERICAL SOLUTION %%%%%%%%%%%
%%% 
%%% y(:,1) = gamma(tau), y(:,2) = dgamma/dtau (horizontal semi-axis)
%%% dimensionless time: tau = sqrt(Om_sq) * t

tau_end = 5.5 * Tper * sqrt(Om_sq); 
options = odeset('RelTol',10^(-8),'AbsTol',10^(-8),'MaxStep',tau_end/20000);

[tau,y]=ode23tb(@system_stretching_drop_2D,[0 tau_end],[gam0 dgam0],options);  
v1 = y(:,1); % gam
v2 = y(:,2); % dgam/dtau

time = tau/sqrt(Om_sq);  % DIMENSIONAL time 
gam  = v1;
dgam = v2 * sqrt(Om_sq); % DIMENSIONAL dgamma/dt

A = dgam./gam; % DIMENSIONAL velocity coefficient

time_o_T = time/Tper;   %dimensionless time (scaled by period!)<<<



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
plot(time_o_T,gam)
title('dimensionless elongation')
xlabel('time/T')
ylabel('\gamma')


%%% PRESSURE FIELD at the ORIGIN
%%% reference scale for pressure field: 
%%% p^* = Omega_sq * R^2 * rho0
%
ddgam = (2 * v2.^2 + (v1.^2) .* (1 - v1.^4) )./ ...
        ( v1.* (1 + v1.^4));
ddgam = ddgam * Om_sq;  % DIMENSIONAL dgamma^2/dt^2
dA    = (gam.*ddgam - dgam.^2)./(gam.^2);

% dimensionless pressure: p* = p /rho_0 / (R^2* Omega^2)  
p_adim = 0.5 *(gam.^2) .* ( Om_sq + A.^2 + dA )/Om_sq;

figure(2)
plot(time_o_T,p_adim)
title('dimensionless pressure at the origin')
xlabel('time/T')
ylabel('p^*')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% ENERGY TERMS %%%

% TOTAL MECHANICAL ENERGY
% NOTE: the mechanical energy is displayed in order to check
% the numerical dissipation induced by the numerical integration of the ODEs. 
% Indeed, in theory the total mechanical energy has to be constant in time.
HH = (1+v1.^4)./(2*v1.^4);
FF = (1+v1.^4)./(2*v1.^2);
Etot = HH.*(v2.^2)+FF-CC0;  %NOTE: defined up to an unessential constant value

figure(4)
plot(time_o_T,Etot)
title('dimensionless TOTAL ENERGY')
subtitle('-- check on numerical dissipation --')
xlabel('time/T')
ylabel('E_{tot}^*')

% POTENTIAL and KINETIC energies
Epot = 1/4 * FF;
Ekin = 1/4 * HH.*(v2.^2);

figure(5)
plot(time_o_T,Epot)
title('dimensionless POTENTIAL ENERGY')
xlabel('time/T')
ylabel('E_{pot}^*')

figure(6)
plot(time_o_T,Ekin)
title('dimensionless KINETIC ENERGY')
xlabel('time/T')
ylabel('E_{kin}^*')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
