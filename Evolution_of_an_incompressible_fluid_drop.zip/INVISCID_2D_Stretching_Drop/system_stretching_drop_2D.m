%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% System of ODEs for the 2D INVISCID stretching DROP %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% y(1) indicates the variable "gamma", that is the DIMENSIONLESS elongation 
% of the ellipse semi-axis along the horizontal direction, 
% y(2) is the time derivative of "gamma" (with respect to the DIMENSIONLESS time)

function dy = system_stretching_drop_2D(~,y)

dy = zeros(2,1);

dy(1) = y(2);
dy(2) = ( 2*y(2)^2 + y(1)^2 * (1-y(1)^4) )/(y(1)*(1+y(1)^4));