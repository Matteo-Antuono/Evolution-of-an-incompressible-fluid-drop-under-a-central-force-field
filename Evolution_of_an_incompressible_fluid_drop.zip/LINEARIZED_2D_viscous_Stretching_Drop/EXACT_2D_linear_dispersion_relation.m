%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 2D viscous stretching drop with surface tension %%%%
%%%                                                   %%
%%% EXACT solution of the linearized problem          %%
%%% The numerical solution is obtained through        %% 
%%% a Newton method with a dynamic coefficient        %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear
clc


% physical parameters
sigma=0.5;     % surface tension parameter
R=0.2;         % drop radius
Omega_sq = 0;  % coefficient of the central force field // Omega^2


% other physical parameter
n  = 6;         % mode number (integer) // allowed 2 <= n <= 8
nu = 0.01;      % cinematic visosity


% DIMENSIONLESS parameters
q = (sigma * R)/nu^2;
p = (Omega_sq * R^4)/nu^2;
% compound paramter of the linear dispersion relation 
Un = n *( p  + (n^2-1) * q );
% perturbation parameter 
epsilon = 0.01; 



% % IN ALTERNATIVE:
% % Direct assignment of (n, Un)
%
% n  =  2;
% Un = 50; 
% 
% n  = 8;
% Un = 50000;
%
% n  = 6;
% Un = 3360000; %1120000; %560000; %



% DIMENSIOLESS PARAMETERS
disp('DIMENSIOLESS PARAMETERS')
disp([' force/visc,      p = ',num2str(p)])
disp([' surf_tens/visc,  q = ',num2str(q)])
disp([' mode number,     n = ',num2str(n)])
disp([' compound parameter,          Un = ', num2str(Un)])
disp([' perturbation parameter, epsilon = ', num2str(epsilon)])
disp('---------------------------------------------')




% The INITIAL GUESS of the Newton's method is given by the funtion "set_initial_guess".
% This partially relies on the solution obtained through the Lamb's method (1932)
[z0_p,z0_m,rk,Us,Uss]=set_initial_guess(n,Un);

if (rk==1)
  disp('regime type: OVERDAMPED')
elseif (rk==2)
  disp('regime type: LOW-range oscillatory regime')
else
  disp('regime type: HIGH-range oscillatory regime')
end

disp(['U*  = ', num2str(Us)])
disp(['U** = ', num2str(Uss)])
disp('---------------------------------------------')

zz_ref = z0_p;
rz_ref = real(zz_ref);
iz_ref = imag(zz_ref);

alpha_adim = zz_ref^2;
disp('===========================================================')




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Newton method with dynamic parameter
%
% Here 'funz' indcates the exact linear dispersion relation, while 'dfunz'
% and 'ddfunz' indicate its first and second order derivatives
U = Un/n;

z0 = zz_ref;

funz  = 2 * (z0.^5 - 2 * z0.^3 * n * (-1 + n^2) + z0 * n * U) .* besselj(-1 + n, z0) + ...
        (z0.^6 - 4 * z0.^4 * n^2 - 4 * n^2 * U + z0.^2 * n * (-8 * n + 8 * n^3 + U)) .* besselj(n, z0); 
    
dfunz = (z0.^5 - 2 * z0.^3 * n * (-1 + n^2) + z0 * n * U) .* besselj(-2 + n, z0) + ...
        (z0.^6 + z0.^4 *(10 - 4 *n^2) + 2 *(1 - 2 *n) * n * U + ... 
         z0.^2 * n *(12 + 4 *(-2 + n) *n *(1 + 2 *n) + U)) .* besselj(-1 + n, z0) - ...
       ((z0.^6 * (-5 + n) + 2 * z0.^4 * n * (1 + (8 - 3 * n) * n) - 4 * n^3 * U + ...
         z0.^2 * (-1 + n) * n * (8 * (-2 + n) * n * (1 + n) + U)) .* besselj(n, z0))./z0;
  
ddfunz = 8 * z0 * (-4 * n^2 * z0 + 3 * z0^3) * besselj(n,z0)+...
         2 * (8 * n^4 + n *U + 3 * z0^4 - 8 * n^2 * (1+z0^2)) * besselj(n,z0)+...
         2 * z0 * (8 * n^4 + n*U + 3 * z0^4 - 8 * n^2 * (1+z0^2)) * (besselj(-1+n,z0)-besselj(1+n,z0))+...
         1/4 *(-4 * n^2 * U + (-8 * n^2 + 8 * n^4 + n*U) * z0^2 -...
         4 * n^2 * z0^4 + z0^6) * (besselj(-2+n,z0)-2 * besselj(n,z0)+besselj(2+n,z0));

disp(['initial value:  |funz| = ', num2str(abs(funz))])
disp(['initial value: |dfunz| = ', num2str(abs(dfunz))])
disp('---------------------------')     
 


%%%% NEWTON CYCLES
paro = 0.1;
iter_max = 200000;

funz_ref = funz;
mm=1;
path1(mm) = z0;
while ((abs(funz)/abs(funz_ref)>1.E-12)&&(abs(funz)>1.E-9)&&(mm<iter_max))
    mm=mm+1;

    % % CLASSIC NEWTON METHOD
    % z1 = z0 - funz./dfunz;

    % NEWTON METHOD with dynamic relaxation parameter ('parm')
    ddh = abs( (dfunz^2-funz*ddfunz)/dfunz^2 );
    parm = paro * min(1,1/ddh);
    parm = max(parm, 1.E-10);
    z1 = z0 - parm * funz./dfunz;


    path1(mm) = z1;

    zstep = (z1-z0);
    
    z0 = z1;
    
    funz  = 2 * (z0.^5 - 2 * z0.^3 * n * (-1 + n^2) + z0 * n * U) .* besselj(-1 + n, z0) + ...
        (z0.^6 - 4 * z0.^4 * n^2 - 4 * n^2 * U + z0.^2 * n * (-8 * n + 8 * n^3 + U)) .* besselj(n, z0);

    dfunz = (z0.^5 - 2 * z0.^3 * n * (-1 + n^2) + z0 * n * U) .* besselj(-2 + n, z0) + ...
        (z0.^6 + z0.^4 *(10 - 4 *n^2) + 2 *(1 - 2 *n) * n * U + ... 
         z0.^2 * n *(12 + 4 *(-2 + n) *n *(1 + 2 *n) + U)) .* besselj(-1 + n, z0) - ...
       ((z0.^6 * (-5 + n) + 2 * z0.^4 * n * (1 + (8 - 3 * n) * n) - 4 * n^3 * U + ...
         z0.^2 * (-1 + n) * n * (8 * (-2 + n) * n * (1 + n) + U)) .* besselj(n, z0))./z0;
    
    ddfunz = 8 * z0 * (-4 * n^2 * z0 + 3 * z0^3) * besselj(n,z0)+...
         2 * (8 * n^4 + n *U + 3 * z0^4 - 8 * n^2 * (1+z0^2)) * besselj(n,z0)+...
         2 * z0 * (8 * n^4 + n*U + 3 * z0^4 - 8 * n^2 * (1+z0^2)) * (besselj(-1+n,z0)-besselj(1+n,z0))+...
         1/4 *(-4 * n^2 * U + (-8 * n^2 + 8 * n^4 + n*U) * z0^2 -...
         4 * n^2 * z0^4 + z0^6) * (besselj(-2+n,z0)-2 * besselj(n,z0)+besselj(2+n,z0));

end
   
disp(['final value:  |funz| = ', num2str(abs(funz))])
disp(['final value: |dfunz| = ', num2str(abs(dfunz))])
disp('---------------------------')
disp([' iterations:      nn = ', num2str(abs(mm))])


 


%%% FIGURES %%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
plot(real(path1),imag(path1),'-b+')
hold on
plot(real(z0),imag(z0),'om', MarkerFaceColor='m')
title('path of the Newton method in the complex plane')
subtitle('o = final solution')
xlabel('real axis')
ylabel('imaginary axis')


disp('===========================================================')
disp('---------------------------')
disp('-- DIMENSIONLESS VALUES  --')

disp(['     initial guess: z0 = ', num2str(zz_ref)])

disp(['predicted solution: z0 = ', num2str(z0)])

disp('---------------------------')
disp('--- DIMENSIONAL VALUES  ---')

disp(['     initial guess: alpha0^* = ', num2str(zz_ref^2*nu/R^2)])

disp(['predicted solution: alpha0^* = ',num2str(z0^2*nu/R^2)] )

disp('--------------------------')

disp([' n = ', num2str(n),', Un = ', num2str(Un)])




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% SOLUTION and FIGURES  
%
% DIMENSIOLESS VARIABLES // radius R=1

nnr=151;
nnt=201;

drr = 1/(nnr-1);
dtt = 2*pi/(nnt-1);
rr=0:drr:1;
tt=0:dtt:2*pi;
[RR,TT]=meshgrid(rr,tt);

XX = RR.*cos(TT);
YY = RR.*sin(TT);

Cn = - ( 2 * (n - 1) * n ) / ... 
     ( ( 2 * n * (n + 1) - z0^2 ) * besselj(n,z0) - 2 * z0 * besselj(n-1,z0) );

chi = 1 + Cn * besselj(n,z0);




% reference value for the stream function:
% psi_0 = i * nu * z0^2 / n / chi
%
% where:  chi = Cn * besselj(n, z0) + 1
%
psi0 = 1i * z0^2 /n /chi;


% VORTICITY
%
% vort^* = eps * nu / R^2 
%
vort_ad = Cn *  psi0 * z0^2 * besselj(n,RR* z0) .* sin(n *TT);
vort_ad = epsilon * real(vort_ad);



% DINAMIC PRESSURE
%
% NOTE: the static pressure componetn is:
% press_stat = p/2 *(1-r^2) + q
%
% reference scaling for the dynamics pressure field:
% p_din^* = rho0 * eps * nu^2 / R^2 
%
press_din_ad = psi0 * (RR.^n) * z0^2 .* cos(n * TT);
press_din_ad = epsilon * real(press_din_ad);




% CARTESIAN VELOCITY COMPONENTS
% u0^* = psi_0/R
uu_ad = (psi0 * (Cn * n * besselj(n,RR * z0) .* cos((1+n) *TT) +...
        n * (RR.^n) .* cos((1-n) *TT) + Cn  * RR .* z0 .* besselj(-1+n,RR* z0) .* sin(TT) .* sin(n *TT) ))./RR;
uu_ad(RR==0) = 0;
uu_ad = epsilon * real(uu_ad);

vv_ad = (psi0 * (-Cn * RR .* z0 .* besselj(-1+n,RR*z0) .* cos(TT) .* sin(n * TT)+...
        n * (Cn * besselj(n,RR*z0) .* sin((1+n) * TT) + (RR.^n) .* sin(TT-n *TT))))./RR;
vv_ad(RR==0) = 0;
vv_ad = epsilon * real(vv_ad);


% % KINETIC ENERGY
Ekin_ad = 0.5* ( uu_ad.^2 + vv_ad.^2 );


figure(2)
%surface(XX,YY,vort_ad)
surf(XX,YY,vort_ad)
shading interp
%axis equal
title('vorticity')
xlabel('x')
ylabel('y')
%xlim([-1.1 1.1])
%ylim([-1.1 1.1])


figure(3)
%surface(XX,YY,press_din_ad)
surf(XX,YY,press_din_ad)
shading interp
%axis equal
title('dynamic pressure')
xlabel('x')
ylabel('y')
%%colormap(turbo)
%%colormap(hsv)
%xlim([-1.1 1.1])
%ylim([-1.1 1.1])


figure(4)
%surface(XX,YY,Ekin_ad)
surf(XX,YY,Ekin_ad)
shading interp
%axis equal
title('Kinetic energy')
xlabel('x')
ylabel('y')
%%colormap(turbo)
%%colormap(hsv)
%xlim([-1.1 1.1])
%ylim([-1.1 1.1])


figure(5)
%surface(XX,YY,uu_ad)
surf(XX,YY,uu_ad)
shading interp
%axis equal
title('horizontal velocity')
xlabel('x')
ylabel('y')
%%colormap(turbo)
%%colormap(hsv)
%xlim([-1.1 1.1])
%ylim([-1.1 1.1])



figure(6)
%surface(XX,YY,vv_ad)
surf(XX,YY,vv_ad)
shading interp
%axis equal
title('vertical velocity')
xlabel('x')
ylabel('y')
%%colormap(turbo)
%%colormap(hsv)
%xlim([-1.1 1.1])
%ylim([-1.1 1.1])




%%% RADIAL and ANGULAR VELOCITY 
u_rad = (n * psi0 * (RR.^n + Cn * besselj(n, RR* z0) ) .* cos(n * TT))./RR;
u_rad(RR==0) = 0;
u_rad = epsilon * real(u_rad);

u_the = -((psi0 * (Cn * RR .* z0 .* besselj(-1 + n, RR* z0) +... 
           n * (RR.^n - Cn * besselj(n, RR * z0))) .* sin(n * TT) )./RR);
u_the(RR==0) = 0;
u_the = epsilon * real(u_the);


figure(7)
%surf(RR,TT,u_rad)
surf(XX,YY,u_rad)
shading interp
title('radial velocity')
xlabel('r')
ylabel('\theta')

figure(8)
%surf(RR,TT,u_the)
surf(XX,YY,u_the)
title('angular velocity')
shading interp
xlabel('r')
ylabel('\theta')

