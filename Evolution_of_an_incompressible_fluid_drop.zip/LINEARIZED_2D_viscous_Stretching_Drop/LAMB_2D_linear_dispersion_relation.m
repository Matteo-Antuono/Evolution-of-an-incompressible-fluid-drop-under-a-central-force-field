%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 2D viscous stretching drop with surface tension %%%%
%%%                                                   %%
%%% Solution obtained by using the LAMB method (1932) %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


close all
clear
clc


% physical parameters
sigma=0.5;     % surface tension parameter
R=0.2;         % drop radius
Omega_sq = 0;  % coefficient of the central force field // Omega^2


% other physical parameter
n  = 6;         % mode number (integer >=2)
nu = 0.05; %0.0025;    % cinematic visosity


% DIMENSIONLESS parameters
q = (sigma * R)/nu^2;
p = (Omega_sq * R^4)/nu^2;
% compound paramter of the linear dispersion relation 
Un = n *( p  + (n^2-1) * q );
% perturbation parameter 
epsilon = 0.01; 



% PARAMETRI adimensionali della simulazione
disp('DIMENSIOLESS PARAMETERS')
disp([' force/visc,      p = ',num2str(p)])
disp([' surf_tens/visc,  q = ',num2str(q)])
disp([' mode number,     n = ',num2str(n)])
disp([' compound parameter,          Un = ', num2str(Un)])
disp([' perturbation parameter, epsilon = ', num2str(epsilon)])
disp('---------------------------------------------')




% Reference solution through the Lamb's method (1932)
% DIMENSIONLESS variable 'alpha'
discr = Un-4*n^2*(n-1)^2;
if (discr<0)
    disp('Overdamped solution')
    disp('NOT interesting')
    return
end
Re_alpha_adim = 2*n*(n-1);    % real part of alpha
Im_alpha_adim = sqrt(discr);  % imaginary part of alpha
alpha_adim = Re_alpha_adim + 1i*Im_alpha_adim;

% dimensioless variable "z = sqrt(alpha)" 
zz_ref = sqrt(alpha_adim);
rz_ref = real(zz_ref);
iz_ref = imag(zz_ref);



disp('===========================================================')
disp('---------------------------')
disp('-- DIMENSIONLESS VALUES  --')

disp(['predicted solution: z0 = ', num2str(zz_ref)])


disp('---------------------------')
disp('--- DIMENSIONAL VALUES  ---')

disp(['predicted solution: alpha0^* = ', num2str(zz_ref^2*nu/R^2)])

disp('--------------------------')

disp([' n = ', num2str(n),', Un = ', num2str(Un)])





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% PLOTS // in DIMENSIOLESS variables
%
% We set R=1 (DIMENSIOLESS variables)
%
nnr = 151;  %discretization along the radial direction (r)
nnt = 201;  %discretization along the angular direction (theta)

drr = 1/(nnr-1);
dtt = 2*pi/(nnt-1);
rr = 0:drr:1;    % r
tt = 0:dtt:2*pi; % theta
[RR,TT]=meshgrid(rr,tt);

XX = RR.*cos(TT);
YY = RR.*sin(TT);



% The reference scaling for the stream function 'psi' is:
% psi_0 = i * alpha * R^2 / n
psi0 = 1i * alpha_adim/n;


% mappa blu - rosso
map = [0 0 1
       0.1 0.1 1
       0.2 0.2 1
       0.3 0.3 1
       0.4 0.4 1 
       0.5 0.5 1 
       0.6 0.6 1
       0.7 0.7 1
       0.8 0.8 1
       0.9 0.9 1
       1 1 1 
       1 0.9 0.9
       1 0.8 0.8
       1 0.7 0.7
       1 0.6 0.6
       1 0.5 0.5
       1 0.4 0.4
       1 0.3 0.3
       1 0.2 0.2 
       1 0.1 0.1
       1 0 0];



% DINAMIC PRESSURE
%
% NOTE: the static pressure componetn is:
% press_stat = p/2 *(1-r^2) + q
%
% reference scaling for the dynamics pressure field:
% p_din^* = rho0 * eps * nu^2 / R^2 
%
press_din_ad = psi0 * alpha_adim *  (RR.^n) .* cos(n * TT);
press_din_ad = epsilon * real(press_din_ad);



% CARTESIAN VELOCITY COMPONENTS
% u0^* = psi_0/R
uu_ad = n * psi0 * (RR.^(-1+n)) .* cos(TT-n *TT);
uu_ad(RR==0) = 0;
uu_ad = epsilon * real(uu_ad);

vv_ad = n * psi0 * (RR.^(-1+n)) .* sin(TT-n *TT);
vv_ad(RR==0) = 0;
vv_ad = epsilon *  real(vv_ad);

Ekin_ad = 0.5 * ( uu_ad.^2 + vv_ad.^2 );



figure(1)
%surface(XX,YY,press_din_ad)
surf(XX,YY,press_din_ad)
shading interp
%axis equal
title('dynamic pressure (dimensionless)')
%%colormap(turbo)
%%colormap(hsv)
%colormap(map)
%xlim([-1.1 1.1])
%ylim([-1.1 1.1])


figure(2)
%surface(XX,YY,Ekin_ad)
surf(XX,YY,Ekin_ad)
shading interp
%axis equal
title('Kinetic energy (dimensionless)')
%%colormap(turbo)
%%colormap(hsv)
%colormap(map)
%xlim([-1.1 1.1])
%ylim([-1.1 1.1])


figure(3)
%surface(XX,YY,uu_ad)
surf(XX,YY,uu_ad)
shading interp
%axis equal
title('horizontal velocity (dimensionless)')
%%colormap(turbo)
%%colormap(hsv)
%colormap(map)
%xlim([-1.1 1.1])
%ylim([-1.1 1.1])



figure(4)
%surface(XX,YY,vv_ad)
surf(XX,YY,vv_ad)
shading interp
%axis equal
title('vertical velocity (dimensionless)')
%%colormap(turbo)
%%colormap(hsv)
%colormap(map)
%xlim([-1.1 1.1])
%ylim([-1.1 1.1])


