function [z0_p,z0_m,r_kind,Us,Uss]=set_initial_guess(n,Un)
% 
% This function set the inital guess for the Newton method with
% dynamic coefficient according to the different regimes of motion
% of the 2D EXACT linear dispersion relation
%
% Symbols 'z0_p' and 'z0_m' indicate the initial guesses for the 
% roots of the linear dispersive equation 
%
% 'r_kind' is an index identifying the regimes of the solution:
% 1 => overdamped regime
% 2 => LOW-range oscillatory regime
% 3 => HIGH-range oscillatory regime
%
% 'Us' and 'Uss' are the values of 'Un' that separates the different regimes 
%        Un < Us    =>   overdamped regime
%   Us < Un < Uss   =>   LOW-range oscillatory regime
%  Uss < Un         =>   HIGH-range oscillatory regime
%



% ALL solutions have been defined from n=1 up to n=8
n_min=1;
n_max=8;
if or((n<n_min),(n>n_max))
    disp('worng mode choice')
    disp('mode range is between 2 and 8')
    return
end


% U* // the OVERDAMPED regime occurs for U<U* 
Us = 12.8185 * n^3 - 83.1568 * n^2 + 226.5177 * n - 215.0149;

% U** //the LOW-range oscillatory regime occurs for U* < U < U** 
Uss = 99.6722 * n^4 - 1234.7 * n^3 + 6043.9 * n^2 - 13091 * n + 10312;


if (Un<=Us) %% overdamped regime

    r_kind = 1;

    discr = Un-4*n^2*(n-1)^2;
    alpha_adim_p = 2*n*(n-1) + sqrt(discr);
    alpha_adim_m = 2*n*(n-1) - sqrt(discr); 
    z0_p = 0.72*sqrt(alpha_adim_p);
    z0_m = 1.50*sqrt(alpha_adim_m);

elseif (Un>Uss) %% HIGH-range oscillatory regime

    r_kind = 3; 

    discr = Un-4*n^2*(n-1)^2;
    alpha_adim_p = 2*n*(n-1) + 1i * sqrt(discr);
    alpha_adim_m = 2*n*(n-1) - 1i * sqrt(discr); 
    z0_p = sqrt(alpha_adim_p);
    z0_m = sqrt(alpha_adim_m);

else %% LOW-range oscillatory regime

    r_kind = 2;

    % coefficients of the regression curve for 'z0_p' and 'z0_m'
    c2 = zeros(1,n_max);
    c1 = zeros(1,n_max);
    c0 = zeros(1,n_max);

    c2(2) = (9.1493 - 13.0705 * 1i)/1000; 
    c1(2) =  0.0329 +  0.2985 * 1i;
    c0(2) =  1.6666 +  0.0010 * 1i;

    c2(3) = ( 1.2660 - 2.6156 * 1i)/1000;
    c1(3) =   0.0323 + 0.1743 * 1i;
    c0(3) =   2.6031 + 0.0010 * 1i;

    c2(4) = (2.9366 - 8.1391 * 1i)/10000;
    c1(4) =  0.0314 + 0.1190 * 1i;
    c0(4) =  3.4415 + 0.0010 * 1i;

    c2(5) = (0.74035  - 3.1145 * 1i)/10000;
    c1(5) =  0.0303   + 0.0876 * 1i;
    c0(5) =  4.2424   + 0.0010 * 1i;

    c2(6) = (0.052569 - 1.3560 * 1i )/10000;
    c1(6) =  0.0300   + 0.0677 * 1i;
    c0(6) =  5.0010   + 0.0010 * 1i;

    c2(7) = (-0.85928  - 6.9832 * 1i )/100000;
    c1(7) =   0.0282   + 0.0550 * 1i;
    c0(7) =   5.7614   + 0.0010 * 1i;

    c2(8) = (-0.99667  - 3.9911 * 1i )/100000;
    c1(8) =   0.0261   + 0.0461 * 1i;
    c0(8) =   6.5116   + 0.0010 * 1i;


    z0_m = - ( c2(n) * (Un-Us) + c1(n) *sqrt(Un-Us) + c0(n) );
    z0_p = - z0_m;

end

return