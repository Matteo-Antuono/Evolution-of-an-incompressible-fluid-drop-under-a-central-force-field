% ROTATING VISCOUS DROP in a central force field
% in two spatial dimensions
%
% SINGLE-MODE SOLUTION 
%
% Central force field:   f = - Omega^2 * r 
% where 'r' is the radial direction (polar coordinates)
% The radius of the drop is 'R' (assumed equal to 1)
%
%
% NOTE: the solution is expressed in DIMENSIONLESS VARIABLES according to
% the scaling below:
%
% angular velocity:   sigma* = sigma/Omega
% vorticity:           vort* = vort/Omega
% pressure:               p* = p/rho0/Omega^2/R^2  
% time:                   t* = (nu*alpha_n^2/R^2) * t
% 
% where: 
% 'rho0' is the fluid density (assumed to be constant)
% 'nu' is the kinematic viscosity of the fluid
% 'alpha_n' is the n-th non-trivial zero of the Bessel function J2
% 'n' is the mode of the solution.
%
%
% Here we consider three different solutions corresponding to 
% the first three non-trivial zeros of the Bessel function J2.
%
% For each solution we consider three times of the evolution: 
% t0=0 (initial time), t1 and t2
% where t1 and t2 can be modified inside the code.


clear
close all
clc


% First three non-trivial zeros of J2(z) // through 'Mathematica' software
alpha(1) = 5.13562; 
alpha(2) = 8.41724; 
alpha(3) = 11.6198;

% First three non-trivial zeros of J1(z) // through 'Mathematica' software
beta(1) = 3.83171;
beta(2) = 7.01559;
beta(3) = 10.1735;

% First three non-trivial zeros of J0(z) // through 'Mathematica' software
delta(1) = 2.40483;
delta(2) = 5.52008;
delta(3) = 8.65373;


% well-known identities for the Bessel function J1(z):
%
% Limit[ J(1,a*r)/r, r->0 ] = a/2
%
% values at r=1 (i.e. at the free surface) 
%
% J[1,alpha(1)] = -0.339669
% J[1,alpha(2)] =  0.271383
% J[1,alpha(3)] = -0.232443
%
%
% Structure of the solution for the angular velocity:
%
% sigma = A0 + A1 * BesselJ[1, alpha*r]/r * exp(-nu * alpha**2 * t)
%
%
% Values of sigma at the centre of the domain (r=0)
%
% sigma(0) = A0 + A1 * alpha/2
%
% Values of sigma at the free-surface (r=1)
%
% sigma(1) = A0 +  A1 * BesselJ[1, alpha]



% At the initial time (t=0), the coefficients of the solutions are chosen
% in order to enforce:
% o)  sigma(r=0)=1
% o)   vort(r=1)=0
% This leads to the following values:
%
A0(1) = - besselj(0,alpha(1))/(1-besselj(0,alpha(1)));
A1(1) = 2/alpha(1)/(1-besselj(0,alpha(1)));

A0(2) = - besselj(0,alpha(2))/(1-besselj(0,alpha(2)));
A1(2) = 2/alpha(2)/(1-besselj(0,alpha(2)));

A0(3) = - besselj(0,alpha(3))/(1-besselj(0,alpha(3)));
A1(3) = 2/alpha(3)/(1-besselj(0,alpha(3)));

dr = 1/1000;  % spatial discretization
r  = 0:dr:1;


sol=struct([]);
for n=1:3

  % Solutions at the initial time (t=0)
  sol(n).sigma0    = A0(n) + A1(n) * besselj(1,alpha(n)*r)./r;
  sol(n).sigma0(1) = A0(n) + A1(n) * alpha(n)/2;

  sol(n).vort0 = 2*A0(n) + alpha(n) * A1(n) * besselj(0,alpha(n)*r);

  sol(n).pres0 = (1-A0(n))^2 * (1-r.^2)/2 + ...
                 2*A0(n)*A1(n)/alpha(n) *( besselj(0,alpha(n)) - besselj(0,alpha(n)*r) ) +...
                    (A1(n)^2)/2 *( besselj(0,alpha(n))^2 - besselj(0,alpha(n)*r).^2      +...
                                besselj(1,alpha(n))^2 - besselj(1,alpha(n)*r).^2  );

  % Solutions at later times
  % selected times:
  t1=0.5;
  t2=1;

  % damping coefficients
  coe1= exp(-t1);
  coe2= exp(-t2);

  sol(n).r = r;

  sol(n).sigma1    = A0(n) + A1(n) * besselj(1,alpha(n)*r)./r * coe1;
  sol(n).sigma1(1) = A0(n) + A1(n) * alpha(n)/2 * coe1;
  sol(n).sigma2    = A0(n) + A1(n) * besselj(1,alpha(n)*r)./r * coe2;
  sol(n).sigma2(1) = A0(n) + A1(n) * alpha(n)/2 * coe2;

  sol(n).vort1= 2*A0(n) + alpha(n) * A1(n) * besselj(0,alpha(n)*r) * coe1;
  sol(n).vort2= 2*A0(n) + alpha(n) * A1(n) * besselj(0,alpha(n)*r) * coe2;

  sol(n).pres1 = (1-A0(n))^2 * (1-r.^2)/2 + ...
              2*A0(n)*A1(n)/alpha(n) *( besselj(0,alpha(n)) - besselj(0,alpha(n)*r) ) * coe1 +...
                 (A1(n)^2)/2 *( besselj(0,alpha(n))^2 - besselj(0,alpha(n)*r).^2      +...
                                besselj(1,alpha(n))^2 - besselj(1,alpha(n)*r).^2  ) * coe1^2;
  sol(n).pres2 = (1-A0(n))^2 * (1-r.^2)/2 + ...
              2*A0(n)*A1(n)/alpha(n) *( besselj(0,alpha(n)) - besselj(0,alpha(n)*r) ) * coe2 +...
                 (A1(n)^2)/2 *( besselj(0,alpha(n))^2 - besselj(0,alpha(n)*r).^2      +...
                                besselj(1,alpha(n))^2 - besselj(1,alpha(n)*r).^2  ) * coe2^2;


  % figures
  figure(n)
  plot(r, sol(n).sigma0)
  hold on
  plot(r, sol(n).sigma1,'-m')
  plot(r, sol(n).sigma2,'-g')
  legend('t0','t1','t2')
  title(['sigma, mode n = ',num2str(n)])
  
  figure(10+n)
  plot(r, sol(n).vort0)
  hold on
  plot(r, sol(n).vort1,'-m')
  plot(r, sol(n).vort2,'-g')
  legend('t0','t1','t2')
  title(['vorticity, mode n = ',num2str(n)])

  figure(20+n)
  plot(r, sol(n).pres0)
  hold on
  plot(r, sol(n).pres1,'-m')
  plot(r, sol(n).pres2,'-g')
  legend('t0','t1','t2')
  title(['pressure, mode n = ',num2str(n)])

end


